GitHub Pages için: ZIP'i aç ve içindeki index.html, hakkimda.html ve assets klasörünü deponun ana dizinine yükle.
E-posta kartı kaldırıldı. Hakkımda ayrı sayfa olarak açılır. Telefon kartı +212 786 519 126 numarasına gider.
